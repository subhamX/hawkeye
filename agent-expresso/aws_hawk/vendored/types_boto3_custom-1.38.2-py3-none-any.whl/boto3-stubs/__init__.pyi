"""
Type annotations for boto3.__init__ module.

Copyright 2025 Vlad Emelianov
"""

import logging
import sys
from typing import Any, overload

from boto3 import session as session
from boto3.session import Session as Session
from botocore.config import Config
from botocore.session import Session as BotocoreSession
from types_boto3_cloudformation.client import CloudFormationClient
from types_boto3_cloudformation.service_resource import CloudFormationServiceResource
from types_boto3_dynamodb.client import DynamoDBClient
from types_boto3_dynamodb.service_resource import DynamoDBServiceResource
from types_boto3_ec2.client import EC2Client
from types_boto3_ec2.service_resource import EC2ServiceResource
from types_boto3_lambda.client import LambdaClient
from types_boto3_rds.client import RDSClient
from types_boto3_s3.client import S3Client
from types_boto3_s3.service_resource import S3ServiceResource
from types_boto3_sqs.client import SQSClient
from types_boto3_sqs.service_resource import SQSServiceResource

if sys.version_info >= (3, 12):
    from typing import Literal
else:
    from typing_extensions import Literal
__author__: str = ...
__version__: str = ...

DEFAULT_SESSION: Session | None = ...

def setup_default_session(
    *,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    region_name: str | None = ...,
    botocore_session: BotocoreSession | None = ...,
    profile_name: str | None = ...,
) -> None: ...
def set_stream_logger(
    name: str = ...,
    level: int = ...,
    format_string: str | None = ...,
) -> None: ...
def _get_default_session() -> Session: ...

class NullHandler(logging.Handler): ...

@overload
def client(
    service_name: Literal["cloudformation"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> CloudFormationClient:
    """
    Create client for CloudFormation service.
    """

@overload
def client(
    service_name: Literal["dynamodb"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> DynamoDBClient:
    """
    Create client for DynamoDB service.
    """

@overload
def client(
    service_name: Literal["ec2"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> EC2Client:
    """
    Create client for EC2 service.
    """

@overload
def client(
    service_name: Literal["lambda"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> LambdaClient:
    """
    Create client for Lambda service.
    """

@overload
def client(
    service_name: Literal["rds"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> RDSClient:
    """
    Create client for RDS service.
    """

@overload
def client(
    service_name: Literal["s3"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> S3Client:
    """
    Create client for S3 service.
    """

@overload
def client(
    service_name: Literal["sqs"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> SQSClient:
    """
    Create client for SQS service.
    """

@overload
def resource(
    service_name: Literal["cloudformation"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> CloudFormationServiceResource:
    """
    Create ServiceResource for CloudFormation service.
    """

@overload
def resource(
    service_name: Literal["dynamodb"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> DynamoDBServiceResource:
    """
    Create ServiceResource for DynamoDB service.
    """

@overload
def resource(
    service_name: Literal["ec2"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> EC2ServiceResource:
    """
    Create ServiceResource for EC2 service.
    """

@overload
def resource(
    service_name: Literal["s3"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> S3ServiceResource:
    """
    Create ServiceResource for S3 service.
    """

@overload
def resource(
    service_name: Literal["sqs"],
    region_name: str | None = ...,
    api_version: str | None = ...,
    use_ssl: bool | None = ...,
    verify: bool | str | None = ...,
    endpoint_url: str | None = ...,
    aws_access_key_id: str | None = ...,
    aws_secret_access_key: str | None = ...,
    aws_session_token: str | None = ...,
    config: Config | None = ...,
    aws_account_id: str | None = ...,
) -> SQSServiceResource:
    """
    Create ServiceResource for SQS service.
    """
